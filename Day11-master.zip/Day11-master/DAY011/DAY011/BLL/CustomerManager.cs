﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using DAY011.Repository;
using DAY011.Model;
using DAY011.ViewModel;


namespace DAY011.BLL
{
    public class CustomerManager
    {
        CustomerRepository _customerRepository = new CustomerRepository();
        public bool InsertCustomer(Customer customer)
        {
            return _customerRepository.InsertCustomer(customer);
        }
        public List<CustomerViewModel> ShowCustomerInfo()
        {
            return _customerRepository.ShowCustomerInfo();
        }
        public bool UpdateCustomer(Customer customer)
        {
            return _customerRepository.UpdateCustomer(customer);
        }
        public List<CustomerViewModel> SearchCustomer(int Code)
        {
            return _customerRepository.SearchCustomer(Code);
        }
        public bool UniqueCode(Customer customer)
        {
            return _customerRepository.UniqueCode(customer);
        }
        public bool UniqueContact(Customer customer)
        {
            return _customerRepository.UniqueContact(customer);
        }
        public List<District> DistrictCombo()
        {
            return _customerRepository.DistrictCombo();
        }
    }
}
