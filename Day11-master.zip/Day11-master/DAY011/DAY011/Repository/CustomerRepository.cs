﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;
using DAY011.BLL;
using DAY011.Model;
using DAY011.ViewModel;

namespace DAY011.Repository
{
    public class CustomerRepository
    {

        //Save Customer Info
        public bool InsertCustomer(Customer customer)
        {
            bool isAdded = false;
            try

            {
                //Connection
                string connectionString = @"Server=DESKTOP-O7V3738; Database=CustomerInfo; Integrated Security=True";
                SqlConnection sqlConnection = new SqlConnection(connectionString);

                string commandString = @"INSERT INTO Customers Values (" + customer.Code + ",'" + customer.Name + "'," +
                    " + '" + customer.Address + "', '" + customer.Contact + "'," + customer.DistrictId + ")";
                SqlCommand sqlCommand = new SqlCommand(commandString, sqlConnection);

                //Open
                sqlConnection.Open();

                //Insert
                int isExecuted = sqlCommand.ExecuteNonQuery();
                if (isExecuted > 0)
                {
                    //MessageBox.Show("Saved");
                    isAdded = true;
                }
                //else
                //{
                //    //MessageBox.Show("Not Saved");
                //}

                sqlConnection.Close();
            }
            catch (Exception ex)
            {
                //MessageBox.Show("Insert Item Information");
            }
            return isAdded;

        }
        //Update Method
        public bool UpdateCustomer(Customer customer)
        {
            bool exists = false;
            try
            {
                //Connection
                string connectionString = @"Server=DESKTOP-O7V3738; Database=CustomerInfo; Integrated Security=True";
                SqlConnection sqlConnection = new SqlConnection(connectionString);

                //Command 
                string commandString = @"UPDATE Customers SET Name= '" + customer.Name + "',Address = '" + customer.Address + "',Contact= '" + customer.Contact + "',DistrictId="+customer.DistrictId+"  WHERE ID = " + customer.Id + "";
                SqlCommand sqlCommand = new SqlCommand(commandString, sqlConnection);

                //Open
                sqlConnection.Open();

                //Update
                int id=sqlCommand.ExecuteNonQuery();
                if (id>0)
                {
                    exists = true;
                }

                //Close
                sqlConnection.Close();

            }
            catch (Exception ex)
            {
                // MessageBox.Show("Input update Information with ID.");
            }
            return exists;
        }
        //Search method
        public List<CustomerViewModel> SearchCustomer(int Code)
        {
            List<CustomerViewModel> customers = new List<CustomerViewModel>();
            //Connection
            string connectionString = @"Server=DESKTOP-O7V3738; Database=CustomerInfo; Integrated Security=True";
            SqlConnection sqlConnection = new SqlConnection(connectionString);

            //Command 
            string commandString = @"SELECT * FROM CustomerDetailsView  WHERE Code = " + Code + "";
            SqlCommand sqlCommand = new SqlCommand(commandString, sqlConnection);

            //Open
            sqlConnection.Open();

            SqlDataReader sqlDataReader = sqlCommand.ExecuteReader();
         
            while(sqlDataReader.Read())
            {
                CustomerViewModel customer = new CustomerViewModel();
                customer.Id = Convert.ToInt32(sqlDataReader["Id"]);
                customer.Code = Convert.ToInt32(sqlDataReader["Code"]);
                customer.Name = sqlDataReader["Name"].ToString();
                customer.Address = sqlDataReader["Address"].ToString();
                customer.Contact= sqlDataReader["Contact"].ToString();
                customer.Districtt = sqlDataReader["Districtt"].ToString();
                customers.Add(customer);
            }
            //Close
            sqlConnection.Close();
            return customers;
        }
        //Show Method
        public List<CustomerViewModel> ShowCustomerInfo()
        {
            List<CustomerViewModel> customers = new List<CustomerViewModel>();
            //Connection
            string connectionString = @"Server=DESKTOP-O7V3738; Database=CustomerInfo; Integrated Security=True";
            SqlConnection sqlConnection = new SqlConnection(connectionString);
            string commandString = @"SELECT * FROM CustomerDetailsView";
            SqlCommand sqlCommand = new SqlCommand(commandString, sqlConnection);

            //Open
            sqlConnection.Open();

            //Show
            SqlDataReader sqlDataReader = sqlCommand.ExecuteReader();

            while(sqlDataReader.Read())
            {

                CustomerViewModel Viewcustomer = new CustomerViewModel();
                Viewcustomer.Id = Convert.ToInt32(sqlDataReader["Id"]);
                Viewcustomer.Code = Convert.ToInt32(sqlDataReader["Code"]);
                Viewcustomer.Name = sqlDataReader["Name"].ToString();
                Viewcustomer.Address = sqlDataReader["Address"].ToString();
                Viewcustomer.Contact = sqlDataReader["Contact"].ToString();
                Viewcustomer.Districtt = sqlDataReader["Districtt"].ToString();
                    customers.Add(Viewcustomer);
               
            }
            //SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(sqlCommand);
            //DataTable dataTable = new DataTable();
            //sqlDataAdapter.Fill(dataTable);
            //if (dataTable.Rows.Count > 0)
            //{
            //    //showDataGridView.DataSource = dataTable;
            //}
            //else
            //{
            //   // MessageBox.Show("No Data Found");
            //}
            //Close
            sqlConnection.Close();
            return customers;
        }
        //Unique Code
        public bool UniqueCode(Customer customer)
        {
            bool exists = false;
            try
            {
                //Connection

                string connectionString = @"Server=DESKTOP-O7V3738; Database=CustomerInfo ; Integrated Security=True";
                SqlConnection sqlConnection = new SqlConnection(connectionString);

                //Command 
                string commandString = @"SELECT * FROM Customers  WHERE Code = " + customer.Code + " AND Id !="+customer.Id+" ";
                SqlCommand sqlCommand = new SqlCommand(commandString, sqlConnection);

                SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(sqlCommand);
                DataTable dataTable = new DataTable();
                sqlDataAdapter.Fill(dataTable);
                //showDataGridView.DataSource = dataTable;

                //Close
                sqlConnection.Close();
                if (dataTable.Rows.Count > 0)
                {
                    exists = true;
                }
                sqlConnection.Close();
            }
            catch (Exception ex)
            {
                // MessageBox.Show(ex.Message);  
            }
            return exists;
        }
        //Unique Code
        public bool UniqueContact(Customer customer)
        {
            bool exists = false;
            try
            {
                //Connection

                string connectionString = @"Server=DESKTOP-O7V3738; Database=CustomerInfo ; Integrated Security=True";
                SqlConnection sqlConnection = new SqlConnection(connectionString);

                //Command 
                string commandString = @"SELECT Contact FROM Customers  WHERE Contact = '" + customer.Contact + "'  AND Id !=" + customer.Id + " ";
                SqlCommand sqlCommand = new SqlCommand(commandString, sqlConnection);
                
                SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(sqlCommand);
                DataTable dataTable = new DataTable();
                sqlDataAdapter.Fill(dataTable);
                //showDataGridView.DataSource = dataTable;

                //Close
                sqlConnection.Close();
                if (dataTable.Rows.Count > 0)
                {
                    exists = true;
                }
                sqlConnection.Close();
            }
            catch (Exception ex)
            {
                // MessageBox.Show(ex.Message);  
            }
            return exists;
        }
        //District ComboBox
        public List<District> DistrictCombo()
        {
            List<District> districts = new List<District>();
            //Connection
            string connectionString = @"Server=DESKTOP-O7V3738; Database=CustomerInfo; Integrated Security=True";
            SqlConnection sqlConnection = new SqlConnection(connectionString);

            //Command 
            string commandString = @"SELECT Id,Districtt FROM Districts";
            SqlCommand sqlCommand = new SqlCommand(commandString, sqlConnection);

            //Open
            sqlConnection.Open();

            //Show
            SqlDataReader sqlDataReader = sqlCommand.ExecuteReader();
            District district2 = new District();
            district2.Id = 0;
            district2.Districtt = "--Select--"; 
            districts.Add(district2);
            while (sqlDataReader.Read())
            {
                District district = new District();

                district.Id = Convert.ToInt32(sqlDataReader["Id"]);
                district.Districtt = sqlDataReader["Districtt"].ToString();
                districts.Add(district);
            }


            //if (dataTable.Rows.Count > 0)
            //{
            //    return dataTable;
            //    //showDataGridView.DataSource = dataTable;
            //}
            //else
            //{
            //    MessageBox.Show("No Data Found");
            //}

            //Close
            sqlConnection.Close();
            return districts;
        }
    }
}
