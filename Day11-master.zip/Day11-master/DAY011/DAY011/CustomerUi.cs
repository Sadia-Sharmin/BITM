﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DAY011.BLL;
using DAY011.Model;
using DAY011.ViewModel;

namespace DAY011
{
    public partial class CustomerUi : Form
    {
        CustomerManager _customerManager = new CustomerManager();
        Customer _customer = new Customer();
        public CustomerUi()
        {
            InitializeComponent();
        }

        //Add Button
        private void saveButton_Click(object sender, EventArgs e)
        {
            if (String.IsNullOrEmpty(codeTextBox.Text))
            {
                
                codeErrorLabel.Text = @"Code Requred!!";
                codeErrorLabel.ForeColor = Color.Red;
                //MessageBox.Show("Code Requred!!");
                return;
            }
            else if (String.IsNullOrEmpty(customerNameTextBox.Text))
            {
                nameErrorLabel.Text = @"Name Requred!!";
                nameErrorLabel.ForeColor = Color.Red;
                //MessageBox.Show("Name Requred!!");
                return;
            }
            else if (String.IsNullOrEmpty(customerNoTextBox.Text))
            {
                ContactErrorLevel.Text = @"Contact Requred!!";
                ContactErrorLevel.ForeColor = Color.Red;
                // MessageBox.Show("Contact Requred!!");
                return;
            }
            else
            {
                _customer.Code = Convert.ToInt32(codeTextBox.Text);
                _customer.Name = customerNameTextBox.Text;
                _customer.Contact = customerNoTextBox.Text;
                _customer.Address = addressTextBox.Text;
                _customer.DistrictId = Convert.ToInt32(districtComboBox.SelectedValue);
                if (_customerManager.UniqueCode(_customer))
                {
                    //MessageBox.Show("Code already exits");
                    codeErrorLabel.Text = @"Code already exits.";
                    codeErrorLabel.ForeColor = Color.Red;
                    return;
                }
                if (_customerManager.UniqueContact(_customer))
                {
                    MessageBox.Show("Contact already exits");
                    //codeErrorLabel.Text = @"Code already exits.";
                    return;
                }

                if (codeTextBox.Text.Length != 4)
                {
                    //MessageBox.Show("Code Must be 4 Digit.");
                    codeErrorLabel.Text = @"Code Must be 4 Digit. !";
                    codeErrorLabel.ForeColor = Color.Red;
                    return;
                }

                if (customerNoTextBox.Text.Length != 11)
                {
                    //MessageBox.Show("Contact Must be 11 digit.");
                    ContactErrorLevel.Text = @"Contact Must be 11 digit.";
                    ContactErrorLevel.ForeColor = Color.Red;
                    return;
                }

                if (_customer.DistrictId == 0)
                {
                    MessageBox.Show("select district");
                    return;
                }

                if (saveButton.Text == "Save")
                {
                    if (_customerManager.InsertCustomer(_customer))
                    {
                        MessageBox.Show("Saved");
                        showDataGridView.DataSource = _customerManager.ShowCustomerInfo();
                    }
                    else
                    {
                        MessageBox.Show("Not Saved");
                    }
                }
                else
                {
                    if (_customerManager.UpdateCustomer(_customer))
                    {
                        saveButton.Text = "Save";
                        MessageBox.Show("Updated");
                        codeTextBox.Enabled = true;
                        codeTextBox.Text = "";
                        customerNameTextBox.Text = "";
                        addressTextBox.Text = "";
                        customerNoTextBox.Text = "";
                        showDataGridView.DataSource = _customerManager.ShowCustomerInfo();
                    }
                    else
                    {
                        MessageBox.Show("Not updated");
                    }

                }

            }         
        }

        //Search
        private void searchButton_Click(object sender, EventArgs e)
        {
            _customer.Code= Convert.ToInt32(codeTextBox.Text);
            showDataGridView.DataSource = _customerManager.SearchCustomer(Convert.ToInt32(codeTextBox.Text));
        }

        private void CustomerUi_Load(object sender, EventArgs e)
        {
            //show
            nameErrorLabel.Text = "";
            ContactErrorLevel.Text = "";
            codeErrorLabel.Text = "";
            showDataGridView.DataSource = _customerManager.ShowCustomerInfo();
            districtComboBox.DataSource = _customerManager.DistrictCombo();
        }


        private void codeTextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            char chr = e.KeyChar;
            if (!Char.IsDigit(chr) && chr != 8)
            {
                e.Handled = true;
                
                codeErrorLabel.Text = @"Only numeric value !";
                codeErrorLabel.ForeColor = Color.Red;
                return;
            }
        }

        private void showDataGridView_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                if (showDataGridView.CurrentRow != null) showDataGridView.CurrentRow.Selected = true;
                saveButton.Text = "Update";
                codeTextBox.Enabled = false;
                _customer.Id = Convert.ToInt32(showDataGridView.Rows[e.RowIndex].Cells[1].Value);
                codeTextBox.Text = showDataGridView.Rows[e.RowIndex].Cells[2].Value.ToString();
                customerNameTextBox.Text = showDataGridView.Rows[e.RowIndex].Cells[3].Value.ToString();
                customerNoTextBox.Text = showDataGridView.Rows[e.RowIndex].Cells[4].Value.ToString();
               addressTextBox.Text = showDataGridView.Rows[e.RowIndex].Cells[5].Value.ToString();
                districtComboBox.Text = showDataGridView.Rows[e.RowIndex].Cells[6].Value.ToString();
            }
         }

        private void f(object sender, EventArgs e)
        {

        }

        private void codeTextBox_Leave(object sender, EventArgs e)
        {
            codeErrorLabel.Text = "";
        }

        private void customerNameTextBox_Leave(object sender, EventArgs e)
        {
            nameErrorLabel.Text = "";
        }

        private void customerNoTextBox_Leave(object sender, EventArgs e)
        {
            ContactErrorLevel.Text = "";
        }
    }
}
