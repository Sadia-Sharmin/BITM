﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAY011.Model
{
    public class District
    {
        public int Id { set; get; }
        public string Districtt { set; get; }
    }
}
