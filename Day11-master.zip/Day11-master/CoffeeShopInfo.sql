USE CustomerInfo


CREATE TABLE Customers
(
Id INT IDENTITY(1,1) PRIMARY KEY,
Code INT,
Name VARCHAR(50),
[Address] VARCHAR(200),
Contact VARCHAR(50),
DistrictId INT REFERENCES Districts(Id)
)

DROP TABLE Customers

INSERT INTO Customers VALUES ('1111','Ali', 'Dhaka' ,'01311369369',1)
INSERT INTO Customers VALUES ('1112','Hasan', 'Sylhet' ,'01711369369',2)
INSERT INTO Customers VALUES ('1113','Rafi', 'BNorisal' ,'01811369369',3)

SELECT * FROM Customers

DELETE FROM Customers WHERE Id = 21
CREATE TABLE Districts
(
Id INT IDENTITY(1,1) PRIMARY KEY,
Districtt VARCHAR(50)
)
DROP TABLE Districts

INSERT INTO Districts VALUES('Dhaka')
INSERT INTO Districts VALUES('Chittagong')
INSERT INTO Districts VALUES('Barisal')
INSERT INTO Districts VALUES('Khulna')
INSERT INTO Districts VALUES('Mymensing')
INSERT INTO Districts VALUES('Rajshahi')
INSERT INTO Districts VALUES('Sylhet')


SELECT * FROM Districts



CREATE VIEW CustomerDetailsView
AS
SELECT c.Id,Code,Name,[Address],Contact,Districtt FROM Customers As c
LEFT JOIN Districts as d ON d.Id=c.DistrictId

SELECT * FROM CustomerDetailsView