﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Assignment_2
{
    public partial class Customer : Form
    {
        public Customer()
        {
            InitializeComponent();
        }
        //Connection
        string connectionString = @"Server=DESKTOP-O7V3738; Database=CoffeeShop; Integrated Security=True";

        private void Coffee_Shop_Load(object sender, EventArgs e)
        {

        }
        //Insert Button
        private void addButton_Click(object sender, EventArgs e)
        {
           bool flag= UniqueCustomerName(customerNameTextBox.Text);
            if (flag==true)
            {
                MessageBox.Show("Name already exits");
                return;
            }
            else
            {
                InsertCustomer();
            }
        }

        //Delete Button
        private void deleteButton_Click(object sender, EventArgs e)
        {
            DeleteCustomer();
        }

        //Show Button
        private void showButton_Click(object sender, EventArgs e)
        {
            ShowCustomerInfo();
        }
        //update Button
        private void updateButton_Click(object sender, EventArgs e)
        {
            UpdateCustomer();
        }
        //Search Button
        private void searchButton_Click(object sender, EventArgs e)
        {
            SearchCustomer();
        }

        //Insert Method
        private void InsertCustomer()
        {
            try

            {
                    SqlConnection sqlConnection = new SqlConnection(connectionString);

                    string commandString = @"INSERT INTO Customer (Name, Contact, Address, Code) Values ('" + customerNameTextBox.Text + "', " + customerNoTextBox.Text + "," +
                        " + '" + addressTextBox.Text + "', " + codeTextBox.Text + ")";
                    SqlCommand sqlCommand = new SqlCommand(commandString, sqlConnection);

                    //Open
                    sqlConnection.Open();

                    //Insert
                    int isExecuted = sqlCommand.ExecuteNonQuery();
                    if (isExecuted > 0)
                    {
                        MessageBox.Show("Saved");
                    }

                    else
                    {
                        MessageBox.Show("Not Saved");
                    }


                    sqlConnection.Close();
                }
            catch (Exception ex)
            {
                MessageBox.Show("Insert Customer Information");
            }

        }

        private void showDataGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
        //Delete Method
        private void DeleteCustomer()
        {
            try
            {
                string connectionString = @"Server=DESKTOP-O7V3738; Database=CoffeeShop; Integrated Security=True";
                SqlConnection sqlConnection = new SqlConnection(connectionString);

                //Command 
                //DELETE FROM Items WHERE ID = 3
                string commandString = @"DELETE FROM Customer WHERE ID = " + idtextBox.Text + "";
                SqlCommand sqlCommand = new SqlCommand(commandString, sqlConnection);

                //Open
                sqlConnection.Open();

                //Delete
                sqlCommand.ExecuteNonQuery();

                //Close
                sqlConnection.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Which ID!!");
            }
        }

        //Show Method
        private void ShowCustomerInfo()
        {
            SqlConnection sqlConnection = new SqlConnection(connectionString);
            string commandString = @"SELECT * FROM Customer";
            SqlCommand sqlCommand = new SqlCommand(commandString, sqlConnection);

            //Open
            sqlConnection.Open();

            //Show
            SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(sqlCommand);
            DataTable dataTable = new DataTable();
            sqlDataAdapter.Fill(dataTable);
            if (dataTable.Rows.Count > 0)
            {
                showDataGridView.DataSource = dataTable;
            }
            else
            {
                MessageBox.Show("No Data Found");
            }
            //Close
            sqlConnection.Close();
        }
        //Update Method
        private void UpdateCustomer()
        {
            try { 
            SqlConnection sqlConnection = new SqlConnection(connectionString);

            //Command 
            string commandString = @"UPDATE Customer SET Name= '" + customerNameTextBox.Text + "',Contact= " + customerNoTextBox.Text + ",Address = '" + addressTextBox.Text + "',Code= " + codeTextBox.Text + "  WHERE ID = " + idtextBox.Text + "";
            SqlCommand sqlCommand = new SqlCommand(commandString, sqlConnection);

            //Open
            sqlConnection.Open();

            //Update
            sqlCommand.ExecuteNonQuery();

            //Close
            sqlConnection.Close();
        }
            catch(Exception ex)
            {
                MessageBox.Show("Input update Information with ID.");
            }
}
        //Search method
        private void SearchCustomer()
        {
            try
            {
            string connectionString = @"Server=DESKTOP-O7V3738; Database=CoffeeShop; Integrated Security=True";
            SqlConnection sqlConnection = new SqlConnection(connectionString);

                //Command 
                string commandString = @"SELECT * FROM Customer  WHERE Name = '" + customerNameTextBox.Text + "'";
                SqlCommand sqlCommand = new SqlCommand(commandString, sqlConnection);

                SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(sqlCommand);
                DataTable dataTable = new DataTable();
                sqlDataAdapter.Fill(dataTable);
            showDataGridView.DataSource = dataTable;
           
                //Close
                sqlConnection.Close();
            }
            catch(Exception ex)
            {
                MessageBox.Show("Give an ID");
            }
        }

        private bool UniqueCustomerName(string name)
        {
            try
            {
                string connectionString = @"Server=DESKTOP-O7V3738; Database=CoffeeShop; Integrated Security=True";
                SqlConnection sqlConnection = new SqlConnection(connectionString);

                //Command 
                string commandString = @"SELECT * FROM Customer  WHERE Name = '" + name + "'";
                SqlCommand sqlCommand = new SqlCommand(commandString, sqlConnection);

                SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(sqlCommand);
                DataTable dataTable = new DataTable();
                sqlDataAdapter.Fill(dataTable);
                showDataGridView.DataSource = dataTable;

                //Close
                sqlConnection.Close();
                if (dataTable.Rows.Count > 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return false;
            }
        }


    }
}


