﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Assignment_2
{
    public partial class Order : Form
    {

        public Order()
        {
            InitializeComponent();
        }
        //Connection
        string connectionString = @"Server=DESKTOP-O7V3738; Database=CoffeeShop; Integrated Security=True";

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void addButton_Click(object sender, EventArgs e)
        {
            InsertCustomer();
        }
        private void showButton_Click(object sender, EventArgs e)
        {
            ShowCustomerInfo();
        }

        private void deleteButton_Click(object sender, EventArgs e)
        {
            DeleteCustomer();
        }

        private void updateButton_Click(object sender, EventArgs e)
        {
            UpdateCustomer();
        }

        private void searchButton_Click(object sender, EventArgs e)
        {
            SearchCustomer();
        }
        //Insert Method
        private void InsertCustomer()
        {
            try { 
            SqlConnection sqlConnection = new SqlConnection(connectionString);
            string commandString = @"INSERT INTO Orders (CustomerName, ItemName, Quantity,TotalPrice) Values ('" + customerNameTextBox.Text + "',  '" + itemNameTextBox.Text + "'," + quantityTextBox.Text + ", " + totalPriceTextBox.Text + ")";
            SqlCommand sqlCommand = new SqlCommand(commandString, sqlConnection);

            //Open
            sqlConnection.Open();

            //Insert
            int isExecuted = sqlCommand.ExecuteNonQuery();
            if (isExecuted > 0)
            {
                MessageBox.Show("Saved");
            }
            else
            {
                MessageBox.Show("Not Saved");
            }

            sqlConnection.Close();
        }
            catch(Exception ex)
            {
                MessageBox.Show("Insert Order Information");
            }
}
        //Delete Method
        private void DeleteCustomer()
        {
            try { 
            SqlConnection sqlConnection = new SqlConnection(connectionString);

            //Command 
            //DELETE FROM Items WHERE ID = 3
            string commandString = @"DELETE FROM  Orders WHERE ID = " + idtextBox.Text + "";
            SqlCommand sqlCommand = new SqlCommand(commandString, sqlConnection);

            //Open
            sqlConnection.Open();

            //Delete
            sqlCommand.ExecuteNonQuery();

            //Close
            sqlConnection.Close();
        }
            catch(Exception ex)
            {
                MessageBox.Show("Whice ID!!");
            }
}

        //Show Method
        private void ShowCustomerInfo()
        {
            SqlConnection sqlConnection = new SqlConnection(connectionString);
            string commandString = @"SELECT * FROM  Orders";
            SqlCommand sqlCommand = new SqlCommand(commandString, sqlConnection);

            //Open
            sqlConnection.Open();

            //Show
            SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(sqlCommand);
            DataTable dataTable = new DataTable();
            sqlDataAdapter.Fill(dataTable);
            if (dataTable.Rows.Count > 0)
            {
                showDataGridView.DataSource = dataTable;
            }
            else
            {
                MessageBox.Show("No Data Found");
            }
            //Close
            sqlConnection.Close();
        }
        //Update Method
        private void UpdateCustomer()
        {
            try { 
            SqlConnection sqlConnection = new SqlConnection(connectionString);

            //Command 
            string commandString = @"UPDATE  Orders SET CustomerName= '" + customerNameTextBox.Text + "',ItemName = '" + itemNameTextBox.Text + "',Quantity= " + quantityTextBox.Text + ",TotalPrice= " + totalPriceTextBox.Text + "  WHERE ID = " + idtextBox.Text + "";
            SqlCommand sqlCommand = new SqlCommand(commandString, sqlConnection);

            //Open
            sqlConnection.Open();

            //Update
            sqlCommand.ExecuteNonQuery();

            //Close
            sqlConnection.Close();
        }
            catch(Exception ex)
            {
                MessageBox.Show("Input values for update with ID.");
            }
}
        //Search method
        private void SearchCustomer()
        {
            try { 
            SqlConnection sqlConnection = new SqlConnection(connectionString);

            //Command 
            string commandString = @"SELECT * FROM Orders  WHERE CustomerName = '" + customerNameTextBox.Text + "'";
            SqlCommand sqlCommand = new SqlCommand(commandString, sqlConnection);

            //Show
            SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(sqlCommand);
            DataTable dataTable = new DataTable();
            sqlDataAdapter.Fill(dataTable);
            showDataGridView.DataSource = dataTable;

            //Close
            sqlConnection.Close();
        }
            catch(Exception ex)
            {
                MessageBox.Show("Give an ID.");
            }
}

        
    }
}
