﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Assignment_2
{
    public partial class Item : Form
    {
       
        public Item()
        {
            InitializeComponent();
        }
        //Connection
        string connectionString = @"Server=DESKTOP-O7V3738; Database=CoffeeShop; Integrated Security=True";

        private void addButton_Click(object sender, EventArgs e)
        {
            bool flag = UniqueItemName(itemTextBox.Text);
            if (flag == true)
            {
                MessageBox.Show("Item already exits");
                return;
            }
            else
            {
                InsertCustomer();
            }
        }
        private void showButton_Click(object sender, EventArgs e)
        {
            ShowItemInfo();
        }

        private void searchButton_Click(object sender, EventArgs e)
        {
            SearchItem();
        }

        private void updateButton_Click(object sender, EventArgs e)
        {
            UpdateItem();
        }

        private void deleteButton_Click(object sender, EventArgs e)
        {
            DeleteItem();
        }

        //Insert Method
        private void InsertCustomer()
        {
            try { 
            SqlConnection sqlConnection = new SqlConnection(connectionString);
            //Command
            string commandString = @"INSERT INTO Item (Item,Price) Values ('" + itemTextBox.Text + "',  " + priceTextBox.Text + ")";
            SqlCommand sqlCommand = new SqlCommand(commandString, sqlConnection);

            //Open
            sqlConnection.Open();

            //Insert
            int isExecuted = sqlCommand.ExecuteNonQuery();
            if (isExecuted > 0)
            {
                MessageBox.Show("Saved");
            }
            else
            {
                MessageBox.Show("Not Saved");
            }

            sqlConnection.Close();
        }
            catch(Exception ex)
            {
                MessageBox.Show("Insert Item Information");
            }
}
        //Delete Method
        private void DeleteItem()
        {
            try { 
            SqlConnection sqlConnection = new SqlConnection(connectionString);

            //Command 
            string commandString = @"DELETE FROM  Item WHERE ID = " + idtextBox.Text + "";
            SqlCommand sqlCommand = new SqlCommand(commandString, sqlConnection);

            //Open
            sqlConnection.Open();

            //Delete
            sqlCommand.ExecuteNonQuery();

            //Close
            sqlConnection.Close();
        }
            catch(Exception ex)
            {
                MessageBox.Show("Which ID!!");
            }
}

        //Show Method
        private void ShowItemInfo()
        {
            SqlConnection sqlConnection = new SqlConnection(connectionString);
            string commandString = @"SELECT * FROM  Item";
            SqlCommand sqlCommand = new SqlCommand(commandString, sqlConnection);

            //Open
            sqlConnection.Open();

            //Show
            SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(sqlCommand);
            DataTable dataTable = new DataTable();
            sqlDataAdapter.Fill(dataTable);
            if (dataTable.Rows.Count > 0)
            {
                showDataGridView.DataSource = dataTable;
            }
            else
            {
                MessageBox.Show("No Data Found");
            }
            //Close
            sqlConnection.Close();
        }
        //Update Method
        private void UpdateItem()
        {
            try { 
            SqlConnection sqlConnection = new SqlConnection(connectionString);

            //Command 
            string commandString = @"UPDATE  Item SET Item = '" + itemTextBox.Text + "',Price= " + priceTextBox.Text + "  WHERE ID = " + idtextBox.Text + "";
            SqlCommand sqlCommand = new SqlCommand(commandString, sqlConnection);

            //Open
            sqlConnection.Open();

            //Update
            sqlCommand.ExecuteNonQuery();

            //Close
            sqlConnection.Close();
        }
            catch(Exception ex)
            {
                MessageBox.Show("Input values for Update with ID.");
            }
}
        //Search method
        private void SearchItem()
        {
            try { 
            SqlConnection sqlConnection = new SqlConnection(connectionString);

            //Command 
            string commandString = @"SELECT * FROM Item  WHERE Item = '" + itemTextBox.Text  + "'";
            SqlCommand sqlCommand = new SqlCommand(commandString, sqlConnection);

            //Show
            SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(sqlCommand);
            DataTable dataTable = new DataTable();
            sqlDataAdapter.Fill(dataTable);
            showDataGridView.DataSource = dataTable;

            //Close
            sqlConnection.Close();
        }
            catch(Exception ex)
            {
                MessageBox.Show("Give an ID.");
            }
}

        private bool UniqueItemName(string name)
        {
            try
            {
                string connectionString = @"Server=DESKTOP-O7V3738; Database=CoffeeShop; Integrated Security=True";
                SqlConnection sqlConnection = new SqlConnection(connectionString);

                //Command 
                string commandString = @"SELECT * FROM Item WHERE Item = '" + name + "'";
                SqlCommand sqlCommand = new SqlCommand(commandString, sqlConnection);

                SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(sqlCommand);
                DataTable dataTable = new DataTable();
                sqlDataAdapter.Fill(dataTable);
                showDataGridView.DataSource = dataTable;

                //Close
                sqlConnection.Close();
                if (dataTable.Rows.Count > 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return false;
            }
        }



    }
}
